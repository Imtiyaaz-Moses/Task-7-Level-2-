// React and the css for this file is being called.
import React from 'react';
import '../App.css';

// This function will contain all the components to be exported. All the text is in here, with all their Id's and tags.
// There are unordered list tags.
function Skills(props) {
    return (<skills id="App-skills">
    	<h2 id="h2">Skills:</h2>
    	<ul>
    	<br/><br/>
    	<li>Computer Literate - Microsoft Office, PicsArt Editing.</li>
    	<li>Code B Driving License.</li>
    	<li>Athletic</li>
    	<li>Participated in Interclass Football Tournament - (2016 - 2018)</li>
    	</ul><br/></skills>);
}

// The component is being exported and ready to be imported, when needed.
export default Skills;