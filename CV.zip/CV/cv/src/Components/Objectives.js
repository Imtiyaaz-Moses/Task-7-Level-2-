// React and the css for this file is being called.
import React from 'react';
import '../App.css';

// This function will contain all the components to be exported. All the text is in here, with all their Id's and tags.
// There are h2 heading tags and a paragraph tag.
function Objective(props) {
	return(<objective className="App-obj"><br/>
		<h2 id="h2">Objectives:</h2><br/>
		<p id="p1">I have a keen interest to gain work experience with your company. I am currently a Matriculant of South Peninsula High School, which matriculated in December 2018. 
		I am currently looking for employment due to not furthering my studies this current year and as I am unemployed.</p>
		</objective>);
}

// The component is being exported and ready to be imported, when needed.
export default Objective;