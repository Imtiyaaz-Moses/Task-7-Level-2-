// React and the css for this file is being called. The image for the page is also called from the Images folder.
import React from 'react';
import '../App.css';
import logo from '../Images/IM.jpg'

// This function will contain all the components to be exported. All the text is in here, with all their Id's and tags.
// There are h2 and h6 tags, along with an image tag.
function Header(props) {
    return (<header className="App-header"><h2 id="h2">Imtiyaaz Moses</h2><img src={logo} alt="logo"/><br/>
    	<h6 id="h6">41 Third Avenue, Grassy Park, Cape Town, 7941.<br/>
    	071 672 4663<br/>
    	mosesimtiyaaz@gmail.com</h6></header>);
}

// The component is being exported and ready to be imported, when needed.
export default Header;