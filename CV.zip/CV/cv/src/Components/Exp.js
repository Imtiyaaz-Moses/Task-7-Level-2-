// React and the css for this file is being called.
import React from 'react';
import '../App.css';

// This function will contain all the components to be exported. All the text is in here, with all their Id's and tags.
// There are h2,h3 & h4 heading and paragraph tags contain text.
function Exp(props) {
    return (<exp id="App-exp">
    	<h2 id="h2">Experience:</h2><br/>
    	<h3 id="h3">Cassim Medical Anaesthetics</h3>
    	<h4 id="h4">2014 - current.</h4><br/>
    	<p id="pp">Casual vacation and weekend work. Assisting the Medical Engineer with technical work, 
    	assembling and servicing the veterinary anesthetic machines.</p><br/></exp>);
}

// The component is being exported and ready to be imported, when needed.
export default Exp;