// React and the css for this file is being called.
import React from 'react';
import '../App.css';

// This function will contain all the components to be exported. All the text is in here, with all their Id's and tags.
// There are div tags and an unordered list tags.
 function Ref(props) {
    return (<ref id="App-ref">
    	<h2 id="h2">References:</h2><br/>
    	<div id="gr"><ul>
    	<li>Ms. F. Myburgh</li></ul>
    	</div>
    	<div id="gl">Head of Commerce Department<br/>South Peninsula High School
    	<br/>Telephone 021 712 9318<br/></div>
    	<div id="gr"><ul><br/>
    	<li>Ms. S. Reid - Jacobs</li></ul>
    	</div>
    	<div id="gl">Homeroom & Afrikaans Teacher<br/>South Peninsula High School
    	<br/>Telephone 021 712 9318<br/></div></ref>);
}

// The component is being exported and ready to be imported, when needed.
export default Ref;