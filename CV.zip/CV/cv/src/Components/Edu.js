// React and the css for this file is being called.
import React from 'react';
import '../App.css';

// This function will contain all the components to be exported. All the text is in here, with all their Id's and tags.
// There are h3,h4 & h5 heading tags as well as an unordered list, tags and a div.
function Edu(props) {
    return (<edu id="App-edu">
		<h2 id="h2">Education:</h2><br/>
		<h3 id="h3">Grassy Park High School:</h3>
		<h4 id="h4">Years: 2014-2015</h4><br/>
		<div><h5 id="h5">Achievements :</h5><br/>
		<ul id="ul">
		<li>Natural Science - Grade 8(2014).</li>
		<li>Participation in UCT Mathematics Olympiad - Grade 9(2015).</li>
		<li>Top of the class Grade 8 & 9.</li>
		<li>Second in 3000m Interschool Athletics (2015).</li>
		</ul><br/>
		<h3 id="h3">South Peninsula High School:</h3>
		<h4 id="h4">Years: 2016-2018</h4><br/>
		<h5 id="h5">Achievements :</h5><br/>
		<ul id="ul">
		<li>First Aid Level One - Grade 11 (2017).</li>
		<li>Participation in SAIPA National Accounting Olympiad - Grade 12 (2018).</li>
		<li>Certificate of Merit for Dedication to Duty (Prefect) - Grade 12 (2018).</li>
		<li>National Senior Certificate with Bachelors Pass - Grade 12 (2018).</li>
		<li>Sixth in 800m Interschool Athletics (2017 & 2018).</li>
		</ul></div><br/></edu>);
}

// The component is being exported and ready to be imported, when needed.
export default Edu;