// All the components are being imported from the Components folder, so it can be rendered.
import React, { Component } from 'react';
import './App.css';
import Header from './Components/Header';
import Objective from './Components/Objectives';
import Edu from './Components/Edu';
import Exp from './Components/Exp';
import Skills from './Components/Skills';
import Ref from './Components/Ref';

class App extends Component {
    render() {
        return (
            <div className="App">
    <link
  rel="stylesheet"
  href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
  integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS"
  crossorigin="anonymous"
/>
      <Header/>
      <Objective/>
      <Edu/>
      <Exp/>
      <Skills/>
      <Ref/>
    </div>
    // All the components will be displayed in the 'div' tag above.
        );
    }
}


export default App;
// This exports all the components to the HTML, so the page can render.