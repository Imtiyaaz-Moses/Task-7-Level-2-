import React from 'react';
import LoginPage from './Login';
function Header(props) {
    return (<header className="App-header">
		<h1><img id="logo" src="./goons.png" alt="Logo"/>Welcome to Goonzquad</h1>
		<h3>Simply Built</h3>
		<h4>You Love To Build?</h4>
		<LoginPage/></header>);
}

export default Header;